The text files in this repository are C++ interview questions being considered
for inclusion in a hackerrank-based automatic screening test.

