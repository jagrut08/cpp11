The current best-of-class candidates for the final test are:

- [AlexanderBeels_1](AlexanderBeels_1)
- [AlisdairMeredith_1](AlisdairMeredith_1)
- [ClayWilson_1](ClayWilson_1)
- [HenryVerschell_1](HenryVerschell_1)
- [HenryVerschell_3](HenryVerschell_3)
- [HymanRosen_1](HymanRosen_1)
- [HymanRosen_3](HymanRosen_3)
- [JohnLakos_1](JohnLakos_1)
- [MikeGiroux_2](MikeGiroux_2)
- [RohanBhindwale_1](RohanBhindwale_1)
