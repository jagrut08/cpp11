#include <iostream>
#include <memory>
int main() {
	std::shared_ptr<int> n;
}
